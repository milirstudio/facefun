/* ============================================================
   脸趣 FaceFun · 应用逻辑
   依赖：face-api.js（由 loader.js 预先加载）
   ============================================================ */
(function () {
  'use strict';

  // ---------- DOM ----------
  var $ = function (s) { return document.querySelector(s); };
  var dropzone   = $('#dropzone');
  var fileInput  = $('#fileInput');
  var canvasWrap = $('#canvasWrap');
  var canvas     = $('#canvas');
  var ctx        = canvas.getContext('2d');
  var detecting  = $('#detecting');
  var popover    = $('#facePopover');
  var toolActions= $('#toolActions');
  var stageHint  = $('#stageHint');
  var btnDetect  = $('#btnDetect');
  var btnReupload= $('#btnReupload');
  var faceList   = $('#faceList');
  var faceCount  = $('#faceCount');
  var btnSelectAll = $('#btnSelectAll');
  var btnSelectNone= $('#btnSelectNone');
  var tabs       = $('#tabs');
  var mosaicRange= $('#mosaicRange');
  var mosaicVal  = $('#mosaicVal');
  var blurRange  = $('#blurRange');
  var blurVal    = $('#blurVal');
  var emojiPalette = $('#emojiPalette');
  var customText = $('#customText');
  var btnApplyText = $('#btnApplyText');
  var btnApply   = $('#btnApply');
  var btnReset   = $('#btnReset');
  var btnExport  = $('#btnExport');
  // 背景自定义控件
  var bgEnable   = $('#bgEnable');
  var bgControls = $('#bgControls');
  var bgColorInput = $('#bgColor');
  var bgColorChip  = $('#bgColorChip');
  var bgAlphaEl   = $('#bgAlpha');
  var bgAlphaVal  = $('#bgAlphaVal');

  // ---------- 常量 ----------
  // 低饱和度人脸标注色板（与 styles.css --face-* 对应）
  var FACE_COLORS = ['#6B8E8E', '#8A6B5C', '#7A7A9A', '#8E8E5C', '#6E8A6E', '#9A7A8A', '#5C7A8A', '#8E6E6E'];
  var EMOJIS = ['😎','🤡','🐵','🤖','👻','😺','🦊','🐸','🐻','🐼','🦁','🐯','🐷','🐮','🐶','🐔','🐧','🦄','👽','🤠','😈','💩','🎃','🌮','🍕','🍩','⚽','🎮','❤️','⭐','🌈','🎉'];
  var MAX_DIM = 1600;       // 工作画布最大边长（兼顾质量与性能）
  var INPUT_SIZE = 416;     // TinyFaceDetector 输入尺寸
  var SCORE_THR = 0.4;

  // ---------- 状态 ----------
  var img = null;          // 原始 HTMLImageElement（干净源）
  var scale = 1;           // natural → canvas 缩放比
  var faces = [];          // {id, box, color, effect}
  var selected = new Set();
  var op = 'mosaic';
  var mosaicSize = 16;
  var blurRadius = 12;
  var emojiValue = '';    // 当前 emoji 文本值（emoji 或文字）
  var faceReady = false;

  // Emoji/文字遮挡的背景设置：默认透明
  var bgEnabled = false;
  var bgColor   = '#FFFFFF';
  var bgAlpha   = 0.80;

  // ============================================================
  // 工具
  // ============================================================
  function toast(msg) {
    var t = document.createElement('div');
    t.className = 'toast'; t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 300); }, 2200);
  }

  function roundRect(c, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  function isEmojiStr(s) {
    if (!s) return false;
    // 去除变体选择符后判断是否为单一图形符号
    var cleaned = s.replace(/[\uFE0F\u200D]/g, '');
    if (cleaned.length > 2) return false;
    return /\p{Extended_Pictographic}/u.test(cleaned);
  }

  function clampFaces(box) {
    box.x = Math.max(0, box.x);
    box.y = Math.max(0, box.y);
    box.width  = Math.min(box.width,  canvas.width  - box.x);
    box.height = Math.min(box.height, canvas.height - box.y);
    return box;
  }

  // 把 #RRGGBB + alpha(0~1) 转为 rgba() 字符串
  function hexToRgba(hex, alpha) {
    var h = hex.replace('#', '');
    if (h.length === 3) h = h.split('').map(function (c) { return c + c; }).join('');
    var r = parseInt(h.substr(0, 2), 16);
    var g = parseInt(h.substr(2, 2), 16);
    var b = parseInt(h.substr(4, 2), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
  }

  // 当前背景设置快照（用于实时预览与应用到 effect）
  function currentBg() {
    return { enabled: bgEnabled, color: bgColor, alpha: bgAlpha };
  }

  // ============================================================
  // Emoji 调色板
  // ============================================================
  function buildPalette() {
    EMOJIS.forEach(function (e) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'emoji-btn'; b.textContent = e;
      b.addEventListener('click', function () {
        emojiValue = e;
        customText.value = '';
        syncPaletteActive();
        updateApplyBtn();
        render();
      });
      emojiPalette.appendChild(b);
    });
  }
  function syncPaletteActive() {
    [].forEach.call(emojiPalette.children, function (b) {
      b.classList.toggle('is-active', b.textContent === emojiValue);
    });
  }

  // ============================================================
  // Tabs
  // ============================================================
  tabs.addEventListener('click', function (e) {
    var t = e.target.closest('.tab'); if (!t) return;
    op = t.dataset.op;
    [].forEach.call(tabs.children, function (c) { c.classList.toggle('is-active', c === t); });
    [].forEach.call(document.querySelectorAll('.oppanel'), function (p) { p.classList.toggle('is-active', p.dataset.op === op); });
    updateApplyBtn();
    render();
  });

  // 滑块 = 实时预览
  mosaicRange.addEventListener('input', function () { mosaicSize = +this.value; mosaicVal.textContent = mosaicSize; render(); });
  blurRange.addEventListener('input', function () { blurRadius = +this.value; blurVal.textContent = blurRadius; render(); });

  customText.addEventListener('input', function () {
    emojiValue = this.value;
    syncPaletteActive();
    updateApplyBtn();
    render();
  });

  // ---- 背景自定义控件联动 ----
  function syncBgControls() {
    bgControls.setAttribute('aria-hidden', String(!bgEnabled));
    bgColorChip.style.background = bgEnabled ? hexToRgba(bgColor, bgAlpha) : '#fff';
    bgAlphaVal.textContent = Math.round(bgAlpha * 100) + '%';
    bgColorInput.disabled = !bgEnabled;
    bgAlphaEl.disabled = !bgEnabled;
  }
  bgEnable.addEventListener('change', function () {
    bgEnabled = this.checked;
    syncBgControls();
    render();
  });
  bgColorInput.addEventListener('input', function () {
    bgColor = this.value;
    syncBgControls();
    render();
  });
  bgAlphaEl.addEventListener('input', function () {
    bgAlpha = +this.value / 100;
    syncBgControls();
    render();
  });

  // ============================================================
  // 上传
  // ============================================================
  dropzone.addEventListener('click', function () { fileInput.click(); });
  fileInput.addEventListener('change', function () { if (fileInput.files[0]) loadImage(fileInput.files[0]); });
  ['dragenter', 'dragover'].forEach(function (ev) {
    dropzone.addEventListener(ev, function (e) { e.preventDefault(); dropzone.classList.add('is-drag'); });
  });
  ['dragleave', 'drop'].forEach(function (ev) {
    dropzone.addEventListener(ev, function (e) { e.preventDefault(); dropzone.classList.remove('is-drag'); });
  });
  dropzone.addEventListener('drop', function (e) {
    var f = e.dataTransfer.files[0];
    if (f && f.type.startsWith('image/')) loadImage(f); else toast('请拖入图片文件');
  });

  btnReupload.addEventListener('click', resetAll);

  function loadImage(file) {
    var url = URL.createObjectURL(file);
    var image = new Image();
    image.onload = function () {
      img = image;
      // 计算工作尺寸
      var nw = image.naturalWidth, nh = image.naturalHeight;
      var longest = Math.max(nw, nh);
      scale = longest > MAX_DIM ? MAX_DIM / longest : 1;
      canvas.width  = Math.round(nw * scale);
      canvas.height = Math.round(nh * scale);
      // 重置状态
      faces = []; selected.clear(); emojiValue = ''; customText.value = '';
      // 切到画布视图
      dropzone.hidden = true;
      canvasWrap.hidden = false;
      toolActions.hidden = false;
      btnExport.disabled = true;
      stageHint.textContent = '点击「识别人脸」自动框选 👇';
      renderFaceList();
      render();
    };
    image.onerror = function () { toast('图片加载失败，换一张试试'); URL.revokeObjectURL(url); };
    image.src = url;
  }

  function resetAll() {
    img = null; faces = []; selected.clear(); emojiValue = '';
    fileInput.value = ''; customText.value = '';
    canvasWrap.hidden = true; toolActions.hidden = true;
    dropzone.hidden = false;
    btnExport.disabled = true;
    stageHint.textContent = '先上传一张照片吧 👇';
    renderFaceList();
  }

  // ============================================================
  // 人脸检测
  // ============================================================
  btnDetect.addEventListener('click', detectFaces);

  function detectFaces() {
    if (!img) { toast('请先上传照片'); return; }
    if (!faceReady || !window.faceapi) { toast('模型还在加载，请稍候'); return; }
    detecting.hidden = false;
    btnDetect.disabled = true;
    // 异步执行，让 spinner 显示
    setTimeout(function () {
      var opts = new faceapi.TinyFaceDetectorOptions({ inputSize: INPUT_SIZE, scoreThreshold: SCORE_THR });
      faceapi.detectAllFaces(canvas, opts).then(function (dets) {
        faces = dets.map(function (d, i) {
          var b = { x: d.box.x, y: d.box.y, width: d.box.width, height: d.box.height };
          clampFaces(b);
          return { id: i + 1, box: b, color: FACE_COLORS[i % FACE_COLORS.length], effect: null };
        });
        selected = new Set(faces.map(function (f) { return f.id; })); // 默认全选
        detecting.hidden = true;
        btnDetect.disabled = false;
        btnExport.disabled = faces.length === 0;
        stageHint.textContent = faces.length ? ('识别到 ' + faces.length + ' 张人脸，勾选要操作的') : '未识别人脸，试试更清晰的正脸照';
        renderFaceList();
        updateApplyBtn();
        render();
        if (faces.length === 0) toast('没检测到人脸 😢');
      }).catch(function (err) {
        console.error(err);
        detecting.hidden = true; btnDetect.disabled = false;
        toast('识别失败，请重试');
      });
    }, 60);
  }

  // ============================================================
  // 人脸列表
  // ============================================================
  function renderFaceList() {
    faceCount.textContent = faces.length ? (faces.length + ' 张') : '暂无';
    if (!faces.length) { faceList.innerHTML = '<p class="empty">识别后将在此显示，勾选要操作的人脸。</p>'; return; }
    faceList.innerHTML = '';
    faces.forEach(function (f) {
      var row = document.createElement('div');
      row.className = 'faceitem' + (selected.has(f.id) ? ' is-checked' : '');
      row.innerHTML =
        '<div class="faceitem__swatch" style="background:' + f.color + '">' + f.id + '</div>' +
        '<div class="faceitem__name">人脸 ' + f.id + '</div>' +
        '<div class="faceitem__tag">' + effectTag(f.effect) + '</div>' +
        '<div class="faceitem__box"></div>';
      row.addEventListener('click', function () {
        if (selected.has(f.id)) selected.delete(f.id); else selected.add(f.id);
        renderFaceList(); updateApplyBtn(); render();
      });
      faceList.appendChild(row);
    });
  }
  function effectTag(eff) {
    if (!eff) return '未处理';
    if (eff.type === 'mosaic') return '马赛克';
    if (eff.type === 'blur') return '模糊';
    if (eff.type === 'emoji') return 'Emoji';
    if (eff.type === 'text') return '文字';
    return '';
  }

  btnSelectAll.addEventListener('click', function () { selected = new Set(faces.map(function (f) { return f.id; })); renderFaceList(); updateApplyBtn(); render(); });
  btnSelectNone.addEventListener('click', function () { selected.clear(); renderFaceList(); updateApplyBtn(); render(); });

  function updateApplyBtn() {
    var disable = selected.size === 0;
    if (op === 'emoji' && !emojiValue) disable = true;
    btnApply.disabled = disable;
  }

  // ============================================================
  // 应用 / 重置
  // ============================================================
  btnApply.addEventListener('click', function () {
    if (!selected.size) { toast('请先勾选人脸'); return; }
    var n = 0;
    faces.forEach(function (f) {
      if (!selected.has(f.id)) return;
      if (op === 'mosaic') f.effect = { type: 'mosaic', value: mosaicSize };
      else if (op === 'blur') f.effect = { type: 'blur', value: blurRadius };
      else if (op === 'emoji' && emojiValue) {
        f.effect = isEmojiStr(emojiValue) ? { type: 'emoji', value: emojiValue, bg: currentBg() } : { type: 'text', value: emojiValue, bg: currentBg() };
      }
      n++;
    });
    renderFaceList(); render();
    toast('已应用到 ' + n + ' 张人脸');
  });

  // emoji 面板内“应用文字”：把当前输入框文字提交给所选
  btnApplyText.addEventListener('click', function () {
    var v = customText.value.trim();
    if (!v) { toast('请输入文字或 emoji'); return; }
    if (!selected.size) { toast('请先勾选人脸'); return; }
    emojiValue = v;
    syncPaletteActive();
    var n = 0;
    faces.forEach(function (f) {
      if (!selected.has(f.id)) return;
      f.effect = isEmojiStr(v) ? { type: 'emoji', value: v, bg: currentBg() } : { type: 'text', value: v, bg: currentBg() };
      n++;
    });
    renderFaceList(); render();
    toast('已应用到 ' + n + ' 张人脸');
  });

  btnReset.addEventListener('click', function () {
    faces.forEach(function (f) { f.effect = null; });
    renderFaceList(); render();
    toast('已重置所有效果');
  });

  // ============================================================
  // 画布点击 → 单个人脸 popover
  // ============================================================
  canvas.addEventListener('click', function (e) {
    if (!faces.length) return;
    var rect = canvas.getBoundingClientRect();
    var cx = (e.clientX - rect.left) * (canvas.width / rect.width);
    var cy = (e.clientY - rect.top)  * (canvas.height / rect.height);
    var hit = null;
    for (var i = 0; i < faces.length; i++) {
      var b = faces[i].box;
      if (cx >= b.x && cx <= b.x + b.width && cy >= b.y && cy <= b.y + b.height) { hit = faces[i]; break; }
    }
    if (!hit) { hidePopover(); return; }
    showPopover(hit, cx, cy);
  });

  function showPopover(face, cx, cy) {
    var px = (cx / canvas.width) * 100;
    var py = (cy / canvas.height) * 100;
    var below = py < 28;
    popover.innerHTML =
      '<button class="popover__close" type="button" aria-label="关闭"><span class="material-symbols-rounded">close</span></button>' +
      '<div class="popover__title">为人脸 ' + face.id + ' 选择遮罩</div>' +
      '<div class="popover__grid"></div>' +
      '<input class="popover__input" type="text" maxlength="12" placeholder="或输入文字/emoji…" />';
    var grid = popover.querySelector('.popover__grid');
    EMOJIS.slice(0, 18).forEach(function (e) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'popover__e'; b.textContent = e;
      b.addEventListener('click', function () {
        face.effect = { type: 'emoji', value: e, bg: currentBg() };
        renderFaceList(); render(); hidePopover();
        toast('人脸 ' + face.id + ' 已替换');
      });
      grid.appendChild(b);
    });
    var input = popover.querySelector('.popover__input');
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') {
        var v = input.value.trim(); if (!v) return;
        face.effect = isEmojiStr(v) ? { type: 'emoji', value: v, bg: currentBg() } : { type: 'text', value: v, bg: currentBg() };
        renderFaceList(); render(); hidePopover();
        toast('人脸 ' + face.id + ' 已替换');
      }
    });
    popover.querySelector('.popover__close').addEventListener('click', hidePopover);
    popover.style.left = px + '%';
    popover.style.top  = py + '%';
    popover.style.transform = below ? 'translate(-50%, 18%)' : 'translate(-50%, -118%)';
    popover.hidden = false;
    setTimeout(function () { input.focus(); }, 30);
  }
  function hidePopover() { popover.hidden = true; popover.innerHTML = ''; }
  document.addEventListener('click', function (e) {
    if (popover.hidden) return;
    if (e.target === canvas || popover.contains(e.target)) return;
    hidePopover();
  });

  // ============================================================
  // 渲染
  // ============================================================
  function applyEffect(eff, box) {
    if (!eff) return;
    if (eff.type === 'mosaic') drawMosaic(box, eff.value);
    else if (eff.type === 'blur') drawBlur(box, eff.value);
    else if (eff.type === 'emoji') drawEmojiOrText(box, eff.value, true, eff.bg);
    else if (eff.type === 'text') drawEmojiOrText(box, eff.value, false, eff.bg);
  }

  // 马赛克：对原图区域降采样后放大
  function drawMosaic(box, blockSize) {
    var bw = Math.max(1, Math.floor(box.width / blockSize));
    var bh = Math.max(1, Math.floor(box.height / blockSize));
    var off = document.createElement('canvas');
    off.width = bw; off.height = bh;
    var octx = off.getContext('2d');
    // 从干净原图按 canvas 坐标取区域（scale 还原到原图像素，保证清晰）
    octx.imageSmoothingEnabled = true;
    octx.drawImage(img, box.x / scale, box.y / scale, box.width / scale, box.height / scale, 0, 0, bw, bh);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(off, 0, 0, bw, bh, Math.round(box.x), Math.round(box.y), Math.ceil(box.width), Math.ceil(box.height));
    ctx.imageSmoothingEnabled = true;
  }

  // 高斯模糊：裁剪到人脸区域并模糊
  function drawBlur(box, radius) {
    ctx.save();
    ctx.beginPath();
    roundRect(ctx, box.x, box.y, box.width, box.height, Math.min(box.width, box.height) * 0.12);
    ctx.clip();
    ctx.filter = 'blur(' + radius + 'px)';
    ctx.drawImage(img, box.x / scale, box.y / scale, box.width / scale, box.height / scale, box.x, box.y, box.width, box.height);
    ctx.filter = 'none';
    ctx.restore();
  }

  // Emoji/文字遮挡：背景默认透明，bg.enabled 时填充自定义颜色+透明度
  function drawEmojiOrText(box, content, asEmoji, bg) {
    var cx = box.x + box.width / 2;
    var cy = box.y + box.height / 2;
    ctx.save();
    // 背景填充（仅当用户开启）
    if (bg && bg.enabled) {
      roundRect(ctx, box.x, box.y, box.width, box.height, Math.min(box.width, box.height) * 0.16);
      ctx.fillStyle = hexToRgba(bg.color || '#FFFFFF', bg.alpha != null ? bg.alpha : 1);
      ctx.fill();
    }
    if (asEmoji) {
      var fs = Math.min(box.width, box.height) * 0.72;
      ctx.font = fs + 'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(content, cx, cy + fs * 0.04);
    } else {
      var maxW = box.width * 0.86;
      var size = Math.max(11, box.height * 0.46);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      do {
        ctx.font = '700 ' + size + 'px "Noto Sans SC",sans-serif';
        if (ctx.measureText(content).width <= maxW) break;
        size -= 1;
      } while (size > 10);
      // 文字描边，提升在透明背景下的可读性
      ctx.lineWidth = Math.max(2, size * 0.12);
      ctx.strokeStyle = 'rgba(0,0,0,0.35)';
      ctx.lineJoin = 'round';
      ctx.strokeText(content, cx, cy);
      ctx.fillStyle = '#FFFFFF';
      ctx.fillText(content, cx, cy);
    }
    ctx.restore();
  }

  function drawFaceBox(face) {
    var b = face.box;
    var lw = Math.max(2, canvas.width * 0.004);
    ctx.save();
    ctx.lineWidth = lw;
    ctx.strokeStyle = face.color;
    if (selected.has(face.id)) {
      ctx.setLineDash([]);
    } else {
      ctx.setLineDash([lw * 3, lw * 2]);
      ctx.globalAlpha = 0.55;
    }
    roundRect(ctx, b.x, b.y, b.width, b.height, lw * 2);
    ctx.stroke();
    ctx.globalAlpha = 1; ctx.setLineDash([]);
    // 标签
    var label = '人脸 ' + face.id;
    ctx.font = '700 ' + Math.max(12, canvas.width * 0.022) + 'px "Noto Sans SC",sans-serif';
    var tw = ctx.measureText(label).width + 16;
    var th = Math.max(18, canvas.width * 0.03);
    var ly = b.y - th - 2; if (ly < 0) ly = b.y + 2;
    ctx.fillStyle = face.color;
    roundRect(ctx, b.x, ly, tw, th, th * 0.3);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(label, b.x + 8, ly + th / 2);
    ctx.restore();
  }

  function render() {
    if (!img) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    faces.forEach(function (f) {
      var eff = f.effect;
      // 实时预览：所选人脸在当前操作下显示参数预览
      if (selected.has(f.id)) {
        if (op === 'mosaic') eff = { type: 'mosaic', value: mosaicSize };
        else if (op === 'blur') eff = { type: 'blur', value: blurRadius };
        else if (op === 'emoji' && emojiValue) eff = isEmojiStr(emojiValue) ? { type: 'emoji', value: emojiValue, bg: currentBg() } : { type: 'text', value: emojiValue, bg: currentBg() };
      }
      applyEffect(eff, f.box);
    });
    faces.forEach(drawFaceBox);
  }

  // ============================================================
  // 导出
  // ============================================================
  btnExport.addEventListener('click', function () {
    if (!img) return;
    var ex = document.createElement('canvas');
    ex.width = canvas.width; ex.height = canvas.height;
    var ec = ex.getContext('2d');
    ec.drawImage(img, 0, 0, ex.width, ex.height);
    // 在导出画布上重绘各人脸效果（不带 UI 框）
    faces.forEach(function (f) {
      var eff = f.effect; if (!eff) return;
      if (eff.type === 'mosaic') {
        var bw = Math.max(1, Math.floor(f.box.width / eff.value));
        var bh = Math.max(1, Math.floor(f.box.height / eff.value));
        var off = document.createElement('canvas');
        off.width = bw; off.height = bh;
        off.getContext('2d').drawImage(img, f.box.x / scale, f.box.y / scale, f.box.width / scale, f.box.height / scale, 0, 0, bw, bh);
        ec.imageSmoothingEnabled = false;
        ec.drawImage(off, 0, 0, bw, bh, Math.round(f.box.x), Math.round(f.box.y), Math.ceil(f.box.width), Math.ceil(f.box.height));
        ec.imageSmoothingEnabled = true;
      } else if (eff.type === 'blur') {
        ec.save();
        ec.beginPath();
        roundRect(ec, f.box.x, f.box.y, f.box.width, f.box.height, Math.min(f.box.width, f.box.height) * 0.12);
        ec.clip();
        ec.filter = 'blur(' + eff.value + 'px)';
        ec.drawImage(img, f.box.x / scale, f.box.y / scale, f.box.width / scale, f.box.height / scale, f.box.x, f.box.y, f.box.width, f.box.height);
        ec.filter = 'none';
        ec.restore();
      } else if (eff.type === 'emoji') {
        exportEmoji(ec, f.box, eff.value, true, eff.bg);
      } else if (eff.type === 'text') {
        exportEmoji(ec, f.box, eff.value, false, eff.bg);
      }
    });
    var a = document.createElement('a');
    a.download = '脸趣_FaceFun_' + Date.now() + '.png';
    a.href = ex.toDataURL('image/png');
    a.click();
    toast('已导出照片');
  });

  // 导出用的 Emoji/文字绘制（与预览保持一致：默认透明背景）
  function exportEmoji(ec, box, content, asEmoji, bg) {
    var cx = box.x + box.width / 2, cy = box.y + box.height / 2;
    ec.save();
    if (bg && bg.enabled) {
      roundRect(ec, box.x, box.y, box.width, box.height, Math.min(box.width, box.height) * 0.16);
      ec.fillStyle = hexToRgba(bg.color || '#FFFFFF', bg.alpha != null ? bg.alpha : 1);
      ec.fill();
    }
    if (asEmoji) {
      var fs = Math.min(box.width, box.height) * 0.72;
      ec.font = fs + 'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
      ec.textAlign = 'center'; ec.textBaseline = 'middle';
      ec.fillText(content, cx, cy + fs * 0.04);
    } else {
      var maxW = box.width * 0.86, size = Math.max(11, box.height * 0.46);
      ec.textAlign = 'center'; ec.textBaseline = 'middle';
      do { ec.font = '700 ' + size + 'px "Noto Sans SC",sans-serif'; if (ec.measureText(content).width <= maxW) break; size -= 1; } while (size > 10);
      ec.lineWidth = Math.max(2, size * 0.12);
      ec.strokeStyle = 'rgba(0,0,0,0.35)'; ec.lineJoin = 'round';
      ec.strokeText(content, cx, cy);
      ec.fillStyle = '#FFFFFF'; ec.fillText(content, cx, cy);
    }
    ec.restore();
  }

  // ============================================================
  // 启动
  // ============================================================
  buildPalette();
  updateApplyBtn();
  syncBgControls();
  // 等待 face-api 就绪
  if (window.__facefunReady) { faceReady = true; }
  window.addEventListener('facefun:ready', function () { faceReady = true; });

  // 防止移动端双击缩放干扰画布点击
  document.addEventListener('dblclick', function (e) { if (e.target === canvas) e.preventDefault(); });
})();

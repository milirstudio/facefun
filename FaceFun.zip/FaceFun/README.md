# 脸趣 FaceFun

> 纯前端人脸隐私遮罩工具 · © 2026 米粒工作室

上传照片 → AI 自动框选人脸 → 马赛克 / 高斯模糊 / Emoji 与文字替换 → 一键导出。
**所有处理均在浏览器本地完成，照片不上传服务器。**

## 功能

- 🎯 **自动人脸识别**：基于 [face-api.js](https://github.com/justadudewhohacks/face-api.js)（TinyFaceDetector 模型），多人脸框选标注。
- 🧩 **多种遮罩**：马赛克（强度可调）、高斯模糊（半径可调）、Emoji 替换、自定义文字替换。
- 🖱️ **交互式操作**：勾选人脸批量处理；也可直接点击画布上的人脸框单独替换为 Emoji/文字。
- 👀 **实时预览**：拖动滑块即时看到效果，满意后再「应用」。
- 💾 **一键导出**：导出为原图分辨率的 PNG。
- 📱 **响应式**：适配手机与 PC 屏幕。
- ⏳ **CDN 加载页**：首次打开以多组进度条展示正在从 CDN 拉取的库与模型，无超时限制。

## 部署

纯静态站点，零后端、零构建。

**方式一：直接放到任意静态服务器**
把整个目录上传到 Nginx / Apache / 对象存储 / GitHub Pages / Vercel / Netlify 等任意静态托管即可。

**方式二：本地预览**
```bash
# 任选一种
python3 -m http.server 8080
# 或
npx serve .
```
浏览器打开 `http://localhost:8080`。

> 需联网：首次加载需从 CDN（jsDelivr）拉取 face-api.js 库与人脸检测模型。

## 目录结构

```
FaceFun/
├── index.html    # 页面结构 + SEO + 加载页骨架
├── loader.js     # 资源加载器（多进度条追踪 CDN 字节流）
├── styles.css    # 样式（活力趣味 · 糖果色 · 响应式）
├── app.js        # 应用逻辑（上传/检测/选择/打码/模糊/emoji/导出）
└── README.md
```

## 技术说明

- **人脸检测**：face-api.js + TinyFaceDetector，模型从 jsDelivr CDN 加载。
- **加载进度**：通过拦截 `fetch` 并 `response.clone()` 旁路读取字节流，真实展示库与模型的下载进度。
- **马赛克**：对原图人脸区域降采样后放大，强度由色块大小控制。
- **高斯模糊**：Canvas `ctx.filter = blur(Npx)` 裁剪到人脸区域。
- **Emoji/文字**：在人脸框上绘制半透明白底 + 居中 Emoji 或自适应文字。

## 浏览器兼容

Chrome / Edge / Firefox / Safari 14+（需支持 Canvas filter 与 ES2017+）。

## 隐私

照片仅在你的浏览器内处理，不会上传至任何服务器。

---

© 2026 米粒工作室 · 脸趣 FaceFun

/* ============================================================
   脸趣 FaceFun · 资源加载器
   - 多组进度条，真实追踪 CDN 字节下载
   - 加载 face-api.js 库 + 人脸检测模型 + 字体
   - 无超时限制；失败可重试
   ============================================================ */
(function () {
  'use strict';

  var FACEAPI_URL = 'https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js';
  var MODEL_URL   = 'https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@master/weights';

  // 资源清单（顺序即进度条顺序）
  var ASSETS = [
    { id: 'lib',   label: 'face-api.js 核心库',         match: /face-api[\-.].*\.js(\?.*)?$/i, progress: 0, done: false, indeterminate: false },
    { id: 'model', label: 'TinyFaceDetector 人脸检测模型', match: /tiny_face_detector_model/i,    progress: 0, done: false, indeterminate: false },
    { id: 'font',  label: '字体资源 (Roboto · Noto · Material Symbols)',   match: null,                            progress: 0, done: false, indeterminate: true  }
  ];

  var barsEl   = document.getElementById('loaderBars');
  var hintEl   = document.getElementById('loaderHint');
  var errorEl  = document.getElementById('loaderError');
  var retryBtn = document.getElementById('loaderRetry');

  // ---- 构建进度条 DOM ----
  function buildBars() {
    barsEl.innerHTML = '';
    ASSETS.forEach(function (a) {
      var row = document.createElement('div');
      row.className = 'bar';
      row.innerHTML =
        '<div class="bar__top">' +
          '<span class="bar__label">' + a.label + '</span>' +
          '<span class="bar__pct" data-pct>0%</span>' +
        '</div>' +
        '<div class="bar__track">' +
          '<div class="bar__fill" data-fill></div>' +
        '</div>';
      a._row  = row;
      a._fill = row.querySelector('[data-fill]');
      a._pct  = row.querySelector('[data-pct]');
      barsEl.appendChild(row);
    });
  }

  function setProgress(a, p) {
    a.progress = Math.max(a.progress, Math.min(1, p));
    if (a._fill) {
      a._fill.style.width = (a.progress * 100).toFixed(1) + '%';
      if (a.indeterminate) a._fill.classList.add('is-indet');
    }
    if (a._pct) a._pct.textContent = a.indeterminate ? (a.done ? '100%' : '…') : Math.round(a.progress * 100) + '%';
  }

  function markDone(a) {
    a.done = true;
    a.progress = 1;
    if (a._fill) { a._fill.classList.remove('is-indet'); a._fill.style.width = '100%'; a._fill.classList.add('is-done'); }
    if (a._pct) a._pct.textContent = '100%';
    if (a._row) a._row.classList.add('is-done');
  }

  function allDone() { return ASSETS.every(function (a) { return a.done; }); }

  // ---- 拦截 fetch，按 URL 匹配把字节进度喂给对应资源条 ----
  // 用 response.clone() 旁路读取进度，原响应原样返回，不干扰 face-api/tfjs 内部读取
  var fetchPatched = false;
  function installFetchTracker() {
    if (fetchPatched) return;
    fetchPatched = true;
    var origFetch = window.fetch.bind(window);
    window.fetch = function (input, init) {
      var url = (typeof input === 'string') ? input : (input && input.url) || '';
      var asset = null;
      for (var i = 0; i < ASSETS.length; i++) {
        if (ASSETS[i].match && ASSETS[i].match.test(url)) { asset = ASSETS[i]; break; }
      }
      if (!asset) return origFetch(input, init);

      return origFetch(input, init).then(function (response) {
        if (!response.ok || !response.body || !response.clone) return response;
        var len = response.headers.get('Content-Length');
        if (!len) return response;
        var total = parseInt(len, 10) || 0;
        var loaded = 0;
        asset.indeterminate = false;
        if (asset._fill) asset._fill.classList.remove('is-indet');
        // 旁路读取克隆流，仅用于进度展示
        var reader;
        try { reader = response.clone().body.getReader(); } catch (e) { return response; }
        (function pump() {
          reader.read().then(function (res) {
            if (res.done) { markDone(asset); return; }
            loaded += res.value.length;
            setProgress(asset, total ? loaded / total : 1);
            pump();
          }).catch(function () { /* 进度追踪失败不影响主流程 */ });
        })();
        return response;
      });
    };
  }

  // ---- 加载 face-api.js 库（经 fetch 拦截得到真实进度） ----
  function loadLibrary() {
    return fetch(FACEAPI_URL)
      .then(function (r) { return r.text(); })
      .then(function (code) {
        var blob = new Blob([code], { type: 'application/javascript' });
        var url  = URL.createObjectURL(blob);
        return new Promise(function (resolve, reject) {
          var s = document.createElement('script');
          s.src = url;
          s.onload  = function () { resolve(); };
          s.onerror = function () { reject(new Error('face-api.js 脚本执行失败')); };
          document.head.appendChild(s);
        });
      });
  }

  // ---- 加载人脸检测模型 ----
  function loadModels() {
    var tiny = window.faceapi.nets.tinyFaceDetector;
    return tiny.loadFromUri(MODEL_URL);
  }

  // ---- 加载字体 ----
  function loadFonts() {
    var asset = ASSETS[2];
    var p1 = document.fonts.load('400 16px "Roboto"').catch(function () {});
    var p2 = document.fonts.load('400 16px "Noto Sans SC"').catch(function () {});
    var p3 = document.fonts.load('24px "Material Symbols Rounded"').catch(function () {});
    // 平滑推进 indeterminate 条
    var fake = 0;
    var iv = setInterval(function () {
      fake = Math.min(0.92, fake + Math.random() * 0.06);
      setProgress(asset, fake);
      if (fake >= 0.92) clearInterval(iv);
    }, 220);
    return Promise.all([p1, p2, p3]).then(function () {
      clearInterval(iv);
      markDone(asset);
    });
  }

  // ---- 主流程 ----
  function boot() {
    buildBars();
    installFetchTracker();

    var lib    = ASSETS[0];
    var model  = ASSETS[1];

    // 库：先置为 indeterminate，fetch 命中后会转真实
    lib.indeterminate = true;
    if (lib._fill) lib._fill.classList.add('is-indet');

    loadLibrary()
      .then(function () {
        markDone(lib);
        hintEl.textContent = '正在加载人脸检测模型…';
        model.indeterminate = true;
        if (model._fill) model._fill.classList.add('is-indet');
        return loadModels();
      })
      .then(function () {
        markDone(model);
        return loadFonts();
      })
      .then(function () {
        hintEl.textContent = '准备就绪，进入工作台 ✨';
        finish();
      })
      .catch(function (err) {
        console.error('[FaceFun] 加载失败:', err);
        showError();
      });
  }

  function showError() {
    hintEl.hidden = true;
    errorEl.hidden = false;
  }

  function finish() {
    // 等所有条收尾动画
    setTimeout(function () {
      var loader = document.getElementById('loader');
      loader.classList.add('is-leaving');
      setTimeout(function () {
        loader.style.display = 'none';
        var app = document.getElementById('app');
        app.hidden = false;
        window.dispatchEvent(new CustomEvent('facefun:ready'));
      }, 600);
    }, 450);
  }

  retryBtn.addEventListener('click', function () {
    // 重置
    errorEl.hidden = true;
    hintEl.hidden = false;
    hintEl.textContent = '从 CDN 拉取资源中，请稍候';
    ASSETS.forEach(function (a) { a.progress = 0; a.done = false; a.indeterminate = (a.id === 'font'); });
    boot();
  });

  // 启动
  boot();
})();
